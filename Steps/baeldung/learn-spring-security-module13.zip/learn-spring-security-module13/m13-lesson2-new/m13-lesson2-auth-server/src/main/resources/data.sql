insert into User (id, created, email, password) values (1, NOW(), 'john@test.com', '123');
insert into User (id, created, email, password) values (2, NOW(), 'tom@test.com', 'abc');
insert into User (id, created, email, password) values (3, NOW(), 'jane@test.com', 'test');