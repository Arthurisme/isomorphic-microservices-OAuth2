# Module 13 - OAuth2 Beyond﻿ ﻿the ﻿﻿REST API
This is the codebase for Module 13 of [Learn Spring Security](http://bit.ly/github-lss)
