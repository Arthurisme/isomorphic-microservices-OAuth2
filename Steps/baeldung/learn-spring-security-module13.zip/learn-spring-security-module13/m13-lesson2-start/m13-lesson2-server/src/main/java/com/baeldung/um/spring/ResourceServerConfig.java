package com.baeldung.um.spring;

import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;

// @Configuration
// @EnableResourceServer
public class ResourceServerConfig extends ResourceServerConfigurerAdapter {

}