package com.baeldung.test.common.test.contract;

public interface IResourceWithAssociationsIntegrationTest {

    void givenResourceHasAssociations_whenResourceIsRetrieved_thenAssociationsAreAlsoRetrieved();

}
