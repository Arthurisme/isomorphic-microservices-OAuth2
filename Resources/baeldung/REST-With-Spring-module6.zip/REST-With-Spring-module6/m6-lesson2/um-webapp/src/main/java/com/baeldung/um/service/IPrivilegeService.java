package com.baeldung.um.service;

import com.baeldung.common.persistence.service.IService;
import com.baeldung.um.persistence.model.Privilege;

public interface IPrivilegeService extends IService<Privilege> {
    //
}
