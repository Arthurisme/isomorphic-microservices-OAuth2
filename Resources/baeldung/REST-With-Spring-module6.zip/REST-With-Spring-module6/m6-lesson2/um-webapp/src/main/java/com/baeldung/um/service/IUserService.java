package com.baeldung.um.service;

import com.baeldung.common.persistence.service.IService;
import com.baeldung.um.persistence.model.User;

public interface IUserService extends IService<User> {
    //

}
