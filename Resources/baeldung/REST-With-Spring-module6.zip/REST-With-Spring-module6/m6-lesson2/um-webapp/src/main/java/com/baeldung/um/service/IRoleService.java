package com.baeldung.um.service;

import com.baeldung.common.persistence.service.IService;
import com.baeldung.um.persistence.model.Role;

public interface IRoleService extends IService<Role> {
    //
}
