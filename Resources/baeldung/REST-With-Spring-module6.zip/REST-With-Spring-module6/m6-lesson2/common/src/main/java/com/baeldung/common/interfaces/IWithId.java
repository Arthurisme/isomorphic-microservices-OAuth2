package com.baeldung.common.interfaces;

public interface IWithId {

    Long getId();

    void setId(final Long id);

}
