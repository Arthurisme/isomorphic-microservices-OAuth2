package com.baeldung.common.persistence.model;

import java.io.Serializable;

import com.baeldung.common.interfaces.IWithId;

public interface IEntity extends IWithId, Serializable {

    //

}
