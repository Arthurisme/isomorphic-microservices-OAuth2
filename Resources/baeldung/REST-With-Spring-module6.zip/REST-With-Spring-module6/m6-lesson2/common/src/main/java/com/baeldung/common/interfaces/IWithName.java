package com.baeldung.common.interfaces;

public interface IWithName {

    String getName();

}
