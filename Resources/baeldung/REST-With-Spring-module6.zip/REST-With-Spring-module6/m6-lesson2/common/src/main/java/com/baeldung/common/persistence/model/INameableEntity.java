package com.baeldung.common.persistence.model;

import com.baeldung.common.interfaces.IWithName;

public interface INameableEntity extends IEntity, IWithName {
    //
}
