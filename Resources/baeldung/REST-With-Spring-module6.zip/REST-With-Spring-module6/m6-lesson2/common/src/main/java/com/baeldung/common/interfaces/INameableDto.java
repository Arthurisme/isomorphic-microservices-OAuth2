package com.baeldung.common.interfaces;

public interface INameableDto extends IDto, IWithName {

    //

}
