package com.baeldung.common.web;

/**
 * Interface that provides some useful constants for the web usage (URLs)
 */
public interface WebConstants {

    String PATH_SEP = "/";

}
