package com.baeldung.common.util;

public enum SearchField {
    id, name, // common
}
