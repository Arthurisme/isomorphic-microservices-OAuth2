package com.baeldung.common.interfaces;

import java.io.Serializable;

public interface IDto extends IWithId, Serializable {

    //

}
