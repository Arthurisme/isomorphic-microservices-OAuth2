package com.baeldung.um.spring;

import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@EnableWebMvc
public class UmWebMvcConfiguration extends WebMvcConfigurerAdapter {

    //

}