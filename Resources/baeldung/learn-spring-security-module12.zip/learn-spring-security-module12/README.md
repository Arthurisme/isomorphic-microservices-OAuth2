# Module 12 - Advanced REST API Security
This is the codebase for Module 12 of [Learn Spring Security](http://bit.ly/github-lss)
