
## Module 1 - Secure a ﻿﻿Simple﻿﻿ Spring MVC Application
This is the codebase for Module 1 of [Learn Spring Security](http://bit.ly/github-lss)
