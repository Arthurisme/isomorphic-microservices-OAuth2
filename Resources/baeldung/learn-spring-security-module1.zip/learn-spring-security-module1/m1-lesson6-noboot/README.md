This lesson code doesn't use Spring Boot. 
