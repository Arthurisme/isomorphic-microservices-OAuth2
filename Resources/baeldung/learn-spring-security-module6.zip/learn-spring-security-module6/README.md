# Module 6 - Password Storage
This is the codebase for Module 6 of [Learn Spring Security](http://bit.ly/github-lss)
