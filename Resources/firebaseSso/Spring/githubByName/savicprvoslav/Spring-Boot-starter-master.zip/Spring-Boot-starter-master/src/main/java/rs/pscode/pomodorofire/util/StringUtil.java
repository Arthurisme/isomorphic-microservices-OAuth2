package rs.pscode.pomodorofire.util;

import org.apache.commons.lang.StringUtils;

public class StringUtil {
	public static Boolean isBlank(String string) {
		return StringUtils.isBlank(string);
	}
}
