package rs.pscode.pomodorofire.web.dto.test;

public class TestRequestJson {

	public TestRequestJson() {

	}

	private String name;

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}
