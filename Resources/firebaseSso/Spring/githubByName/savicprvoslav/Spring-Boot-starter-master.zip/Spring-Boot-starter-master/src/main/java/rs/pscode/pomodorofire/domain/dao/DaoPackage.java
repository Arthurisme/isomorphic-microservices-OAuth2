package rs.pscode.pomodorofire.domain.dao;

/**
 * Used as marker for @EnableJpaRepositories basePackageClasses
 * 
 * @author prvoslav
 *
 */
public interface DaoPackage {

}
