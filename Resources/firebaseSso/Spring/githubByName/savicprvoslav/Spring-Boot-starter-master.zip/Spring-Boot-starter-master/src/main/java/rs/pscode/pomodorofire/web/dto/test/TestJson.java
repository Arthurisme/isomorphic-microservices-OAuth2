package rs.pscode.pomodorofire.web.dto.test;

public class TestJson {

	private Long outId;
	private String name;

	public Long getOutId() {
		return outId;
	}

	public void setOutId(Long outId) {
		this.outId = outId;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

}
