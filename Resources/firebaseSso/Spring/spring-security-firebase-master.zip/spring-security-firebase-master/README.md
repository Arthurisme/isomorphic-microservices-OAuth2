# spring-security-firebase
Spring Security with Firebase Auth

https://awaters1.github.io/Spring-Boot-Single-Sign-On-Firebase-Part-2/

Be sure to setup the Firebase auth within /spring-security-firebase/src/main/java/io/github/awaters1/Application.java
